// Eventzy local server: zero dependencies. Run: node server.js
const http=require('http'),fs=require('fs'),path=require('path'),os=require('os');
const PORT=process.env.PORT||3000,FILE=path.join(__dirname,'data.json');
let db={events:[],regs:[]};
try{db=JSON.parse(fs.readFileSync(FILE,'utf8'))}catch(e){}
function save(){fs.writeFileSync(FILE+'.tmp',JSON.stringify(db,null,2));fs.renameSync(FILE+'.tmp',FILE)}
const send=(res,c,o)=>{res.writeHead(c,{'Content-Type':'application/json'});res.end(JSON.stringify(o))};
const str=(v,n)=>String(v==null?'':v).trim().slice(0,n);
const body=req=>new Promise(r=>{let b='';req.on('data',c=>{b+=c;if(b.length>1e6)req.destroy()});req.on('end',()=>{try{r(JSON.parse(b||'{}'))}catch(e){r({})}})});
http.createServer(async(req,res)=>{
 const u=req.url.split('?')[0];
 if(req.method==='GET'&&u==='/api/state')return send(res,200,db);
 if(req.method==='GET'&&u==='/api/export.csv'){
  const q=v=>'"'+String(v==null?'':v).replace(/"/g,'""')+'"',ev={};db.events.forEach(e=>ev[e.id]=e.name);
  const rows=['Event,Name,Email,Code,Registered at,Checked in at'].concat(db.regs.map(r=>[ev[r.eid],r.name,r.email,r.code,new Date(r.at).toISOString(),r.in?new Date(r.in).toISOString():''].map(q).join(',')));
  res.writeHead(200,{'Content-Type':'text/csv','Content-Disposition':'attachment; filename="eventzy.csv"'});return res.end(rows.join('\n'));}
 if(req.method==='POST'){
  const b=await body(req);
  if(u==='/api/events'){
   const name=str(b.name,120),cap=parseInt(b.cap),id=str(b.id,40);
   if(!id||!name||!(cap>0))return send(res,400,{error:'Name and capacity are required'});
   if(!db.events.some(e=>e.id===id)){db.events.push({id,name,date:str(b.date,20),cap,created:Date.now()});save()}
   return send(res,200,{ok:true});}
  if(u==='/api/regs'){
   const e=db.events.find(x=>x.id===b.eid),code=str(b.id,12).toUpperCase(),name=str(b.name,120),email=str(b.email,160).toLowerCase();
   if(!e)return send(res,404,{error:'Event not found'});
   if(!name||!/^\S+@\S+\.\S+$/.test(email)||!code)return send(res,400,{error:'Valid name and email required'});
   const mine=db.regs.filter(r=>r.eid===e.id);
   if(mine.some(r=>r.email===email))return send(res,409,{error:'This email is already registered'});
   if(mine.length>=e.cap)return send(res,409,{error:'Event is full'});
   if(db.regs.some(r=>r.code===code))return send(res,409,{error:'Code collision, try again'});
   db.regs.push({code,eid:e.id,name,email,at:Date.now(),in:null});save();return send(res,200,{ok:true});}
  if(u==='/api/checkin'){ // single-threaded, so check + write is atomic
   const code=str(b.code,12).toUpperCase(),r=db.regs.find(x=>x.code===code);
   if(!r)return send(res,200,{status:'invalid'});
   if(r.eid!==b.eid){const o=db.events.find(e=>e.id===r.eid);return send(res,200,{status:'wrong_event',other:o?o.name:'another event'});}
   if(r.in)return send(res,200,{status:'duplicate',name:r.name,in:r.in});
   r.in=Date.now();save();return send(res,200,{status:'ok',name:r.name});}
  return send(res,404,{error:'Not found'});}
 if(req.method==='GET'&&(u==='/'||u==='/index.html')){res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});return res.end(fs.readFileSync(path.join(__dirname,'index.html')));}
 send(res,404,{error:'Not found'});
}).listen(PORT,'0.0.0.0',()=>{
 console.log('\n  Eventzy is running\n  On this laptop : http://localhost:'+PORT);
 Object.values(os.networkInterfaces()).flat().filter(i=>i.family==='IPv4'&&!i.internal).forEach(i=>console.log('  On your phone  : http://'+i.address+':'+PORT+'  (same Wi-Fi)'));
 console.log('  Data file      : '+FILE+'\n');});
