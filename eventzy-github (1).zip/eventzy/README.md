# Eventzy 🎟️ — College Event Registration & Check-In

> Code Carnival 3.0 · ADSC, Atmiya University
> Problem statement: **EventEase — College Event Registration & Check-In**

Organizers often run registrations and attendance on disconnected forms and spreadsheets, which causes duplicate entries and slow check-ins. **Eventzy** puts everything in one app: create an event, register participants, give each a unique QR/entry code, verify it at the gate, and reject a second check-in with the same code.

## Features
- Create an event with a **participant capacity** (registration stops when full)
- Register participants (name + email, one registration per email per event)
- Auto-generated **unique 6-character entry code + QR code** for every participant
- **Check-in** by scanning the QR (camera) or typing the code
- **Duplicate check-in is rejected**; invalid and wrong-event codes are rejected too
- Live **dashboard**: registered, checked-in, capacity used, attendance rate, participant list
- **CSV export** of all data, profile sheet, light/dark mode, animations
- Installable on **Android / iOS** as a PWA (Add to Home Screen)
- Data is stored automatically in `data.json` on the organizer's laptop

## Demo scenario
Press **▶ Demo** in the app: it registers a participant, checks them in, then rejects a second check-in using the same code.

## Screenshots
| Register + QR | Duplicate rejected | Dashboard |
|---|---|---|
| ![Register](docs/register-qr.png) | ![Duplicate](docs/checkin-duplicate-rejected.png) | ![Dashboard](docs/dashboard.png) |

## Tech stack
| Layer | Technology |
|---|---|
| Frontend | HTML, CSS, JavaScript (single-page PWA) |
| Backend | Node.js (no dependencies) REST API |
| Storage | JSON file (`data.json`) |
| Libraries | [qrcodejs](https://github.com/davidshimjs/qrcodejs) (QR generation), [jsQR](https://github.com/cozmo/jsQR) (QR scanning) |

## How to run
1. Install [Node.js](https://nodejs.org) (LTS, v14 or newer). Check with `node -v`.
2. Clone or download this repository and open a terminal in its folder.
3. Start the server:
   ```bash
   node server.js
   ```
4. Open **http://localhost:3000** on the laptop. The terminal also prints an address for phones on the **same Wi-Fi** (e.g. `http://192.168.x.x:3000`).
5. Data is saved to `data.json` automatically. Use **Profile → CSV** to export.

> **Phone camera note:** browsers only allow camera access on HTTPS or localhost. On plain `http://192.168...` phones can still type the code. For camera scanning on phones, use a tunnel such as `cloudflared tunnel --url http://localhost:3000` and open the HTTPS link. If phones cannot connect, allow Node.js through the laptop firewall.

## API
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/state` | All events and registrations |
| POST | `/api/events` | Create an event (`id, name, date, cap`) |
| POST | `/api/regs` | Register a participant (checks capacity + duplicate email) |
| POST | `/api/checkin` | Verify a code; returns `ok`, `duplicate`, `invalid` or `wrong_event` |
| GET | `/api/export.csv` | Download all data as CSV |

Check-in is decided on the server in a single step, so two scanners cannot both accept the same code.

## Team
| Role | Name |
|---|---|
| Team Leader | [Your Name] |
| Member | [Name] |
| Member | [Name] |

**Team ID:** [Your Team ID]

## Credits
QR generation by qrcodejs and scanning by jsQR (both MIT-licensed). All other code was written by our team for Code Carnival 3.0.
